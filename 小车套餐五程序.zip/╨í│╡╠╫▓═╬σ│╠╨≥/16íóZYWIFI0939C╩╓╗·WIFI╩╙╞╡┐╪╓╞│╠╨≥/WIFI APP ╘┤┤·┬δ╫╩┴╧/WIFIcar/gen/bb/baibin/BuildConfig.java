/** Automatically generated file. DO NOT MODIFY */
package bb.baibin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}